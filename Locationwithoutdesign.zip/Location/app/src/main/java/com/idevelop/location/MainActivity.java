package com.idevelop.location;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    public void CallGestureRecScreen(View view) {
        Intent intent = new Intent(getApplicationContext(), GestureRecognition.class);
        startActivity(intent);
    }

    public void CallGetRouterPositionScreen(View view) {
        Intent intent = new Intent(getApplicationContext(), GetRouterPosition.class);
        startActivity(intent);
    }

    public void CallInformationScreen(View view) {
        Intent intent = new Intent(getApplicationContext(), GetGPSPosition.class);
        startActivity(intent);
    }


    public void CallDataColleScreen(View view) {
        Intent intent = new Intent(getApplicationContext(), DataCollection.class);
        startActivity(intent);
    }
}
